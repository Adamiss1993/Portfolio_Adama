## faire le CORRECTIF ENVIRONNEMENT PROJ/GDAL (À EXÉCUTER EN PREMIER)


```python
import os
import pyproj

os.environ["PROJ_LIB"] = pyproj.datadir.get_data_dir()
os.environ["PROJ_DATA"] = pyproj.datadir.get_data_dir()

print("PROJ_LIB utilisé :", os.environ["PROJ_LIB"])
```

    PROJ_LIB utilisé : C:\Users\diane\AppData\Local\Programs\Python\Python314\Lib\site-packages\pyproj\proj_dir\share\proj
    

## Charger les Librairies


```python
import osmnx as ox
import city2graph
import geopandas as gpd
import matplotlib.pyplot as plt
import contextily as cx
from matplotlib.lines import Line2D
from shapely.geometry import box

city2graph.__version__
```




    '0.1.6'



## Afficher les limites Administratives


```python
city_name = "Bordeaux metropole, France"
admin = ox.geocode_to_gdf(city_name)
admin.plot()
```




    <Axes: >




    
![png](output_5_1.png)
    


## Accessibilité aux équipements sportifs Aix


```python
#Récupération des équipements sportifs (gyms, centres sportifs) à Aix-en-Provence ---
city_name = "Bordeaux Métropole, France, France"
poi_gdf = ox.features_from_place(city_name, {"leisure": ["gym", "sports_centre"]}).to_crs(3944)
#Conversion des géométries en points (centroïdes) ---
poi_gdf["geometry"] = poi_gdf.geometry.centroid
#Nettoyage des données (suppression des géométries manquantes) ---
poi_gdf = poi_gdf.dropna(subset=["geometry"]).reset_index(drop=True)
#Aperçu du résultat ---
poi_gdf.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>geometry</th>
      <th>leisure</th>
      <th>name</th>
      <th>sport</th>
      <th>addr:housenumber</th>
      <th>addr:street</th>
      <th>ref:FR:NAF</th>
      <th>ref:FR:SIREN</th>
      <th>ref:FR:SIRET</th>
      <th>source</th>
      <th>...</th>
      <th>service:climbing_rope:rental</th>
      <th>service:climbing_rope:rental:fee</th>
      <th>opening_date</th>
      <th>hot_water</th>
      <th>architect</th>
      <th>type</th>
      <th>charge</th>
      <th>covered</th>
      <th>length</th>
      <th>source:heritage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>POINT (1402335.421 3300829.479)</td>
      <td>sports_centre</td>
      <td>Salle Polyvalente Colette Besson</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>POINT (1415242.723 3297415.971)</td>
      <td>sports_centre</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>POINT (1416389.305 3299242)</td>
      <td>sports_centre</td>
      <td>Tennis Badminton Meriadeck</td>
      <td>tennis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>POINT (1417769.393 3298959.613)</td>
      <td>sports_centre</td>
      <td>Echiquier bordelais</td>
      <td>chess</td>
      <td>36</td>
      <td>Rue Buhan</td>
      <td>93.29Z</td>
      <td>480366046</td>
      <td>48036604600013</td>
      <td>INSEE - 2025-03</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>POINT (1417265.584 3298599.34)</td>
      <td>sports_centre</td>
      <td>Arts martiaux</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 100 columns</p>
</div>



## Liste des grap


```python
dir(city2graph)
```




    ['PackageNotFoundError',
     '__author__',
     '__builtins__',
     '__cached__',
     '__doc__',
     '__file__',
     '__loader__',
     '__name__',
     '__package__',
     '__path__',
     '__spec__',
     '__version__',
     'add_metapaths',
     'bridge_nodes',
     'contextlib',
     'contiguity_graph',
     'create_isochrone',
     'create_tessellation',
     'data',
     'delaunay_graph',
     'dual_graph',
     'euclidean_minimum_spanning_tree',
     'filter_graph_by_distance',
     'fixed_radius_graph',
     'gabriel_graph',
     'gdf_to_nx',
     'gdf_to_pyg',
     'get_od_pairs',
     'graph',
     'group_nodes',
     'is_torch_available',
     'knn_graph',
     'load_gtfs',
     'load_overture_data',
     'mobility',
     'morphological_graph',
     'morphology',
     'nx_to_gdf',
     'nx_to_pyg',
     'od_matrix_to_graph',
     'private_to_private_graph',
     'private_to_public_graph',
     'process_overture_segments',
     'proximity',
     'public_to_public_graph',
     'pyg_to_gdf',
     'pyg_to_nx',
     'relative_neighborhood_graph',
     'segments_to_graph',
     'transportation',
     'travel_summary_graph',
     'utils',
     'validate_gdf',
     'validate_nx',
     'validate_pyg',
     'version',
     'waxman_graph']



## FONCTION DE VISUALISATION - GRAPHE PIÉTON


```python
#Définition de la fonction d'affichage (graphe + limite administrative + fond de carte) ---
def plot_pub_graph(edges_gdf, nodes_gdf, admin_gdf, title, color="#00FFFF", alpha=0.5, linewidth=0.75):

    fig, ax = plt.subplots(figsize=(5, 5))

# Affichage de la limite administrative d'Aix-en-Provence ---
    admin_gdf.to_crs(epsg=3944).boundary.plot(ax=ax, color="white", linewidth=1.0, alpha=0.4)

 #Affichage des arêtes du graphe (réseau piéton) ---
    edges_gdf.to_crs(epsg=3944).plot(ax=ax, color=color, linewidth=linewidth, alpha=alpha)

 #Ajout du fond de carte sombre ---
    ctx.add_basemap(ax, source=ctx.providers.CartoDB.DarkMatterNoLabels)

    ax.set_axis_off()
    ax.set_title(title, fontsize=14, color="white", pad=12)
    plt.tight_layout()
    plt.show()
```

## GRAPHE À RAYON FIXE - ACCESSIBILITÉ AUX ÉQUIPEMENTS SPORTIFS


```python
import contextily as cx
import contextily as ctx
# --- Construction du graphe à rayon fixe (1000m) autour des POI d'Aix-en-Provence ---
radius = 1000
fixed_nodes, fixed_edges = city2graph.fixed_radius_graph(poi_gdf, radius=radius)

# --- Visualisation du graphe à rayon fixe sur fond de carte ---
plot_pub_graph(fixed_edges, poi_gdf, admin, "Fixed-radius Graph - Bordeaux Métropole", color="#00FFFF")
```


    
![png](output_13_0.png)
    



```python
import contextily as cx
import contextily as ctx
# --- Construction du graphe à rayon fixe (2500m) autour des POI d'Aix-en-Provence ---
radius = 2500
fixed_nodes, fixed_edges = city2graph.fixed_radius_graph(poi_gdf, radius=radius)

# --- Visualisation du graphe à rayon fixe sur fond de carte ---
plot_pub_graph(fixed_edges, poi_gdf, admin, "Fixed-radius Graph - Bordeaux Métropole", color="#00FFFF")
```


    
![png](output_14_0.png)
    


## CONSTRUCTION DU GRAPHE DE WAXMAN (DISTANCE MANHATTAN)


```python
#Construction du graphe de Waxman avec métrique de distance Manhattan ---
wax_l1_nodes, wax_l1_edges = city2graph.waxman_graph(
    poi_gdf,
    distance_metric="manhattan",
    r0=radius,
    beta=0.5
)
```

## VISUALISATION DU GRAPHE DE WAXMAN 


```python
# --- Affichage du graphe de Waxman sur fond de carte ---
plot_pub_graph(wax_l1_edges, poi_gdf, admin, "Waxman (Manhattan Distance) - Bordeaux Métropole", color="#FF6EFF")
```


    
![png](output_18_0.png)
    


## Pour la distance eucleidienne 


```python
#Construction du graphe de Waxman avec métrique de distance euclidienne ---
wax_l2_nodes, wax_l2_edges = city2graph.waxman_graph(
    poi_gdf,
    distance_metric="euclidean",
    r0=radius,
    beta=0.5
)
```


```python
#Affichage du graphe de Waxman sur fond de carte ---
plot_pub_graph(wax_l2_edges, poi_gdf, admin, "Waxman (Euclidean Distance) - Bordeaux Métropole", color="#00FF9F")
```


    
![png](output_21_0.png)
    


## La distance sur le reseau


```python
# --- Récupération des segments du réseau routier depuis OSM ---
segments_gdf = ox.graph_to_gdfs(ox.graph_from_place(city_name, network_type="drive"))[1].to_crs(3944)
len(segments_gdf)
```




    55172



## GRAPHE DE WAXMAN (DISTANCE RÉSEAU)


```python
# --- Vérification de la cohérence des CRS avant calcul ---
assert poi_gdf.crs == segments_gdf.crs, f"CRS mismatch: {poi_gdf.crs} != {segments_gdf.crs}"

# --- Construction du graphe de Waxman avec métrique de distance réseau ---
wax_net_nodes, wax_net_edges = city2graph.waxman_graph(
    poi_gdf,
    distance_metric="network",
    r0=radius,
    beta=0.5,
    network_gdf=segments_gdf
)
```

    C:\Users\diane\AppData\Local\Programs\Python\Python314\Lib\site-packages\geopandas\geodataframe.py:257: UserWarning: Pandas doesn't allow columns to be created via a new attribute name - see https://pandas.pydata.org/pandas-docs/stable/indexing.html#attribute-access
      super().__setattr__(attr, val)
    

## VISUALISATION - GRAPHE DE WAXMAN (DISTANCE RÉSEAU)


```python
# --- Affichage du graphe de Waxman (distance réseau) sur fond de carte ---
plot_pub_graph(wax_net_edges, poi_gdf, admin, "Waxman (Network Distance) - Bordeaux Metropole", color="#FFA500")
```


    
![png](output_27_0.png)
    


## CONFIGURATION - VILLE, LIMITE ADMINISTRATIVE ET RÉSEAU ROUTIER


```python
# --- Définition de la ville et récupération de la limite administrative, reprojetée en CC44 ---
city_name = "Bordeaux Métropole, France"
admin = ox.geocode_to_gdf(city_name).to_crs(3944)

# --- Récupération des segments du réseau routier, reprojetés en CC44 ---
segments_gdf = ox.graph_to_gdfs(ox.graph_from_place(city_name, network_type="drive"))[1].to_crs(3944)
```

## DÉFINITION DES 4 CATÉGORIES Des Equipements


```python
# --- Requêtes OSM pour les 4 catégories de service (vie active, besoins quotidiens, vie sociale, santé) ---
poi_queries = {
    "Centres_Sport": {"leisure": ["gym", "sports_centre"]},
    "Supermaché": {"shop": ["supermarket", "convenience"]},
    "Restaurant": {"amenity": ["restaurant"]},
    "Service de santé": {"amenity": ["hospital", "clinic", "pharmacy"]}
}
```

## RÉCUPÉRATION DES 4  CATÉGORIES


```python
# --- Récupération, reprojection en CC44 et filtrage des POI de type point pour chaque catégorie ---
poi_layers = {}
for label, query in poi_queries.items():
    poi = ox.features_from_place(city_name, query).to_crs(3944)
    poi_layers[label] = poi[poi.geometry.type == "Point"]
    print(label, len(poi_layers[label]))
```

    Centres_Sport 36
    Supermaché 313
    Restaurant 1170
    Service de santé 240
    

## GRAPHES DE WAXMAN PAR CATÉGORIE DE POI


```python
# --- Construction d'un graphe de Waxman (distance réseau) pour chaque catégorie de POI ---
wax_graphs = {}
radius = 1000
for label, gdf in poi_layers.items():
    if len(gdf) > 1:
        nodes, edges = city2graph.waxman_graph(
            gdf,
            distance_metric="network",
            r0=radius,
            beta=0.5,
            network_gdf=segments_gdf
        )
        wax_graphs[label] = edges
```

    C:\Users\diane\AppData\Local\Programs\Python\Python314\Lib\site-packages\geopandas\geodataframe.py:257: UserWarning: Pandas doesn't allow columns to be created via a new attribute name - see https://pandas.pydata.org/pandas-docs/stable/indexing.html#attribute-access
      super().__setattr__(attr, val)
    


```python
#Nombre de catégories pour lesquelles un graphe a pu être construit ---
len(wax_graphs)
```




    4



## COULEURS PAR CATÉGORIE DE POI 


```python
layer_colors = {
    "Centres_Sport": "#FF69B4",       # rose
    "Supermaché": "#FFFF00",          # jaune
    "Restaurant": "#00FFFF",          # cyan
    "Service de santé": "#00FF00"     # vert
}
```


```python

```

## VISUALISATION GLOBALE - GRAPHES DE WAXMAN PAR CATÉGORIE


```python
# ============================================================
# TEST SANS FOND DE CARTE - ISOLER LA CAUSE DU BLOCAGE
# ============================================================

fig, ax = plt.subplots(figsize=(6, 6))

admin.to_crs(3857).boundary.plot(ax=ax, color="black", linewidth=0.8, zorder=5)

for label, edges in wax_graphs.items():
    edges_3857 = edges.to_crs(3857)
    for _, row in edges_3857.iterrows():
        x, y = row.geometry.xy
        ax.plot(x, y, color=layer_colors[label], linewidth=0.6, alpha=0.3, zorder=6)

for label, pois in poi_layers.items():
    pois.to_crs(3857).plot(ax=ax, markersize=5, color=layer_colors[label], alpha=0.8, zorder=7)

ax.set_title("Métropole de Bordeaux", fontsize=13, pad=12)
plt.tight_layout()
plt.show()
```


    
![png](output_41_0.png)
    



```python
print(list(poi_layers.keys()))
```

    ['Centres_Sport', 'Supermaché', 'Restaurant', 'Service de santé']
    

## VISUALISATION FINALE - CONNECTIVITÉ PIÉTONNE BORDEAUX MÉTROPOLE (Graphes de Waxman + POI + fond de carte)


```python
# ============================================================
# VISUALISATION FINALE - CONNECTIVITÉ PIÉTONNE BORDEAUX MÉTROPOLE
# (Graphes de Waxman + POI + fond de carte)
# ============================================================

import matplotlib.pyplot as plt
import contextily as ctx

fig, ax = plt.subplots(figsize=(6, 6))
fig.patch.set_facecolor("black")

# --- 1. Limite administrative ---
admin.to_crs(3857).boundary.plot(ax=ax, color="white", linewidth=0.8, zorder=5)

# --- 2. Fond de carte (avec sécurité si le téléchargement échoue) ---
try:
    ctx.add_basemap(ax, source=ctx.providers.CartoDB.DarkMatterNoLabels, crs=3857, zoom=10)
except Exception as e:
    print("Fond de carte non chargé (on continue sans) :", e)

# --- 3. Graphes de Waxman (tracé vectorisé, pas de boucle iterrows) ---
for label, edges in wax_graphs.items():
    edges.to_crs(3857).plot(ax=ax, color=layer_colors[label], linewidth=0.6, alpha=0.3, zorder=6)

# --- 4. POI ---
for label, pois in poi_layers.items():
    pois.to_crs(3857).plot(ax=ax, markersize=5, color=layer_colors[label], alpha=0.8, zorder=7)

ax.set_axis_off()
ax.set_title(
    "Connectivité Piétonne aux Besoins Quotidiens à Bordeaux Métropole",
    fontsize=13, color="white", pad=12
)
plt.tight_layout()
plt.show()
```

    Fond de carte non chargé (on continue sans) : The EPSG code is unknown. PROJ: proj_create_from_database: C:\Users\diane\AppData\Local\Programs\Python\Python314\Lib\site-packages\pyproj\proj_dir\share\proj\proj.db contains DATABASE.LAYOUT.VERSION.MINOR = 4 whereas a number >= 6 is expected. It comes from another PROJ installation.
    


    
![png](output_44_1.png)
    


## VISUALISATION GLOBALE - GRAPHES DE WAXMAN - Bordeaux Métropole


```python
from matplotlib.lines import Line2D

fig, ax = plt.subplots(figsize=(6, 6))
fig.patch.set_facecolor("black")  # <-- ajouté, essentiel pour la visibilité du titre blanc

admin.to_crs(3857).boundary.plot(ax=ax, color="white", linewidth=0.8, zorder=5)

for label, edges in wax_graphs.items():
    edges.to_crs(3857).plot(ax=ax, color=layer_colors[label], linewidth=0.6, alpha=0.3, zorder=6)

for label, pois in poi_layers.items():
    pois.to_crs(3857).plot(ax=ax, markersize=5, color=layer_colors[label], alpha=0.8, zorder=7)

ctx.add_basemap(ax, source=ctx.providers.CartoDB.DarkMatterNoLabels, zoom=10)
ax.set_axis_off()

legend_elements = [
    Line2D([0], [0], color=layer_colors[label], lw=3, label=label)
    for label in wax_graphs.keys()
]
ax.legend(
    handles=legend_elements,
    loc="upper left",
    bbox_to_anchor=(0.02, 0.98),
    frameon=True,
    framealpha=1,
    facecolor="black",
    edgecolor="black",
    fontsize=9,
    labelcolor="white",
    title="Bordeaux Métropole",
    title_fontproperties={"weight": "bold", "size": 10}
)

ax.set_title(
    "Connectivité Piétonne aux Besoins Quotidiens à Bordeaux Métropole",
    fontsize=13, color="white", pad=12
)
plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.show()
```


    
![png](output_46_0.png)
    


## DÉFINITION DE LA FONCTION - CONNECTIVITÉ URBAINE


```python
from matplotlib_scalebar.scalebar import ScaleBar

def plot_city_connectivity(city_name, admin, poi_layers, wax_graphs, radius):
    labels_fr = {
        "active_life": "Vie active",
        "daily_needs": "Besoins quotidiens",
        "social_life": "Vie sociale",
        "health_services": "Services de santé"
    }
    fig, ax = plt.subplots(figsize=(8, 6))
    fig.patch.set_facecolor("black")
    admin.to_crs(3857).boundary.plot(ax=ax, color="white", linewidth=0.8, zorder=5)
    for label, edges in wax_graphs.items():
        edges.to_crs(3857).plot(ax=ax, color=layer_colors[label], linewidth=1.0, alpha=0.3, zorder=6)
    for label, pois in poi_layers.items():
        pois.to_crs(3857).plot(ax=ax, markersize=5, color=layer_colors[label], alpha=0.8, zorder=7)
    ctx.add_basemap(ax, source=ctx.providers.CartoDB.DarkMatterNoLabels, zoom=10)
    ax.set_axis_off()

    # --- Légende ---
    legend_elements = [
        Line2D([0], [0], color=color, lw=3, label=labels_fr.get(label, label))
        for label, color in layer_colors.items() if label in wax_graphs
    ]
    ax.legend(
        handles=legend_elements,
        loc="center left",
        bbox_to_anchor=(1.02, 0.5),
        frameon=True,
        framealpha=1,
        facecolor="black",
        edgecolor="black",
        fontsize=9,
        labelcolor="white",
        title="  " + city_name,
        title_fontproperties={"weight": "bold", "size": 10}
    )

    # --- Flèche du Nord ---
    ax.annotate(
    "N", xy=(0.98, 0.94), xytext=(0.98, 0.82),
    xycoords="axes fraction",
    arrowprops=dict(facecolor="white", edgecolor="white", width=4, headwidth=12),
    ha="center", va="center", fontsize=12, color="white", fontweight="bold", zorder=10
)
    

    # --- Échelle (en mètres, données en EPSG:3857) ---
    ax.add_artist(ScaleBar(
    dx=1, units="m", location="lower right",
    box_color="black", box_alpha=0.7, color="white",
    font_properties={"size": 8}, pad=0.3
))

    # --- Source des données ---
    fig.text(
    0.01, 0.07,
    "Source : OpenStreetMap, IGN\nRéalisation : Diané Adama",
    fontsize=7, color="lightgrey", ha="left", va="bottom"
)

    # --- Titres ---
    fig.suptitle(
        f"Accessibilité aux services essentiels: {city_name}",
        fontsize=15, color="white", fontweight="bold", y=0.98
    )
    ax.set_title(
        f"Waxman (Distance Réseau) — r={radius}m",
        fontsize=11, color="lightgrey", pad=10
    )
    plt.tight_layout()
    plt.show()
```

## APPEL 


```python
plot_city_connectivity("Bordeaux Métropole", admin, poi_layers, wax_graphs, radius)
```


    
![png](output_50_0.png)
    


## FONCTION - CONNECTIVITÉ URBAINE AVEC AUTO-ZOOM, MASQUE ET LÉGENDE 


```python
def plot_city_connectivity(city_name, admin, poi_layers, wax_graphs, radius):
    # --- Traduction des catégories pour l'affichage de la légende ---
    labels_fr = {
        "Centres_Sport": "Centres sportifs",
        "Supermaché": "Supermarchés",
        "Restaurant": "Restaurants",
        "Service de santé": "Services de santé"
    }

    fig, ax = plt.subplots(figsize=(6, 6))
    fig.patch.set_facecolor("black")
    admin_3857 = admin.to_crs(3857)
    admin_3857.boundary.plot(ax=ax, color="dimgrey", linewidth=2.0, zorder=5, alpha=0.6)

    wax_graphs_3857 = {}
    for label in ["Centres_Sport", "Supermaché", "Restaurant", "Service de santé"]:
        edges = wax_graphs.get(label)
        if edges is None or edges.empty:
            continue
        edges_3857 = edges.to_crs(3857)
        wax_graphs_3857[label] = edges_3857
        color = layer_colors[label]
        edges_3857.plot(ax=ax, color=color, linewidth=0.6, alpha=0.3, zorder=6)

    ctx.add_basemap(ax, source=ctx.providers.CartoDB.DarkMatterNoLabels, zoom=12)
    ax.set_axis_off()

    all_bounds = [gdf.total_bounds for gdf in wax_graphs_3857.values() if not gdf.empty]
    if all_bounds:
        minx = min(b[0] for b in all_bounds)
        miny = min(b[1] for b in all_bounds)
        maxx = max(b[2] for b in all_bounds)
        maxy = max(b[3] for b in all_bounds)
        buffer_x = (maxx - minx) * 0.05
        buffer_y = (maxy - miny) * 0.05
        zoom_minx = minx - buffer_x
        zoom_maxx = maxx + buffer_x
        zoom_miny = miny - buffer_y
        zoom_maxy = maxy + buffer_y

        outer_box = box(
            zoom_minx - buffer_x,
            zoom_miny - buffer_y,
            zoom_maxx + buffer_x,
            zoom_maxy + buffer_y
        )
        city_shape = admin_3857.geometry.unary_union
        mask_geom = outer_box.difference(city_shape)
        gpd.GeoSeries([mask_geom], crs=admin_3857.crs).plot(
            ax=ax, color="black", zorder=4
        )

    # --- Légende en français (uniquement les catégories non vides) ---
    legend_elements = [
        Line2D([0], [0], color=color, lw=3, label=labels_fr.get(label, label))
        for label, color in layer_colors.items() if label in wax_graphs_3857
    ]

    ax.legend(
        handles=legend_elements,
        loc="lower left",
        bbox_to_anchor=(0.02, -0.02),
        frameon=True,
        framealpha=1,
        facecolor="black",
        edgecolor="black",
        fontsize=9,
        labelcolor="white",
        title="  " + city_name.split(",")[0],
        title_fontproperties={"weight": "bold", "size": 10}
    )

    ax.set_title(
        f"Waxman (Distance Réseau) — Connectivité aux services essentiels à {city_name} (r={radius}m)",
        fontsize=13, color="white", pad=12
    )
    plt.tight_layout()
    plt.show()
```

## Appel


```python
plot_city_connectivity(city_name, admin, poi_layers, wax_graphs, radius)
```

    C:\Users\diane\AppData\Local\Temp\ipykernel_3292\1196764096.py:47: DeprecationWarning: The 'unary_union' attribute is deprecated, use the 'union_all()' method instead.
      city_shape = admin_3857.geometry.unary_union
    


    
![png](output_54_1.png)
    


## FONCTION - CONNECTIVITÉ URBAINE AVEC AUTO-ZOOM, MASQUE avec ZOOM


```python
def plot_city_connectivity(city_name, admin, poi_layers, wax_graphs, radius):

    # --- Traduction des catégories pour l'affichage de la légende ---
    labels_fr = {
        "Centres_Sport": "Centres sportifs",
        "Supermaché": "Supermarchés",
        "Restaurant": "Restaurants",
        "Service de santé": "Services de santé"
    }

    fig, ax = plt.subplots(figsize=(6, 6))
    fig.patch.set_facecolor("black")

    admin_3857 = admin.to_crs(3857)
    admin_3857.boundary.plot(ax=ax, color="dimgrey", linewidth=2.0, zorder=5, alpha=0.6)

    wax_graphs_3857 = {}
    for label in ["Centres_Sport", "Supermaché", "Restaurant", "Service de santé"]:
        edges = wax_graphs.get(label)
        if edges is None or edges.empty:
            continue
        edges_3857 = edges.to_crs(3857)
        wax_graphs_3857[label] = edges_3857
        color = layer_colors[label]
        edges_3857.plot(ax=ax, color=color, linewidth=0.6, alpha=0.3, zorder=6)

    ctx.add_basemap(ax, source=ctx.providers.CartoDB.DarkMatterNoLabels, zoom=12)
    ax.set_axis_off()

    all_bounds = [gdf.total_bounds for gdf in wax_graphs_3857.values() if not gdf.empty]
    if all_bounds:
        minx = min(b[0] for b in all_bounds)
        miny = min(b[1] for b in all_bounds)
        maxx = max(b[2] for b in all_bounds)
        maxy = max(b[3] for b in all_bounds)

        buffer_x = (maxx - minx) * 0.05
        buffer_y = (maxy - miny) * 0.05

        zoom_minx = minx - buffer_x
        zoom_maxx = maxx + buffer_x
        zoom_miny = miny - buffer_y
        zoom_maxy = maxy + buffer_y

        outer_box = box(
            zoom_minx - buffer_x,
            zoom_miny - buffer_y,
            zoom_maxx + buffer_x,
            zoom_maxy + buffer_y
        )

        city_shape = admin_3857.geometry.unary_union
        mask_geom = outer_box.difference(city_shape)

        gpd.GeoSeries([mask_geom], crs=admin_3857.crs).plot(
            ax=ax, color="black", zorder=4
        )

    # --- Légende en français (uniquement les catégories non vides) ---
    legend_elements = [
        Line2D([0], [0], color=color, lw=3, label=labels_fr.get(label, label))
        for label, color in layer_colors.items() if label in wax_graphs_3857
    ]

    ax.legend(
        handles=legend_elements,
        loc="lower left",
        bbox_to_anchor=(0.02, -0.02),
        frameon=True,
        framealpha=1,
        facecolor="black",
        edgecolor="black",
        fontsize=9,
        labelcolor="white",
        title="  " + city_name.split(",")[0],
        title_fontproperties={"weight": "bold", "size": 10}
    )

    ax.set_title(
        f"Waxman (Distance Réseau) — Connectivité aux services essentiels à {city_name} (r={radius}m)",
        fontsize=13, color="white", pad=12
    )
    plt.tight_layout()
    plt.show()
```


```python
plot_city_connectivity(city_name, admin, poi_layers, wax_graphs, radius)
```

    C:\Users\diane\AppData\Local\Temp\ipykernel_3292\975424306.py:52: DeprecationWarning: The 'unary_union' attribute is deprecated, use the 'union_all()' method instead.
      city_shape = admin_3857.geometry.unary_union
    


    
![png](output_57_1.png)
    



```python
%pip install folium
```

    Collecting folium
      Using cached folium-0.20.0-py2.py3-none-any.whl.metadata (4.2 kB)
    Collecting branca>=0.6.0 (from folium)
      Using cached branca-0.8.2-py3-none-any.whl.metadata (1.7 kB)
    Requirement already satisfied: jinja2>=2.9 in c:\users\diane\appdata\local\programs\python\python314\lib\site-packages (from folium) (3.1.6)
    Requirement already satisfied: numpy in c:\users\diane\appdata\local\programs\python\python314\lib\site-packages (from folium) (2.5.0)
    Requirement already satisfied: requests in c:\users\diane\appdata\local\programs\python\python314\lib\site-packages (from folium) (2.34.2)
    Requirement already satisfied: xyzservices in c:\users\diane\appdata\local\programs\python\python314\lib\site-packages (from folium) (2026.3.0)
    Requirement already satisfied: MarkupSafe>=2.0 in c:\users\diane\appdata\local\programs\python\python314\lib\site-packages (from jinja2>=2.9->folium) (3.0.3)
    Requirement already satisfied: charset_normalizer<4,>=2 in c:\users\diane\appdata\local\programs\python\python314\lib\site-packages (from requests->folium) (3.4.7)
    Requirement already satisfied: idna<4,>=2.5 in c:\users\diane\appdata\local\programs\python\python314\lib\site-packages (from requests->folium) (3.18)
    Requirement already satisfied: urllib3<3,>=1.26 in c:\users\diane\appdata\local\programs\python\python314\lib\site-packages (from requests->folium) (2.7.0)
    Requirement already satisfied: certifi>=2023.5.7 in c:\users\diane\appdata\local\programs\python\python314\lib\site-packages (from requests->folium) (2026.6.17)
    Using cached folium-0.20.0-py2.py3-none-any.whl (113 kB)
    Using cached branca-0.8.2-py3-none-any.whl (26 kB)
    Installing collected packages: branca, folium
    
       -------------------- ------------------- 1/2 [folium]
       -------------------- ------------------- 1/2 [folium]
       ---------------------------------------- 2/2 [folium]
    
    Successfully installed branca-0.8.2 folium-0.20.0
    Note: you may need to restart the kernel to use updated packages.
    

    
    [notice] A new release of pip is available: 25.2 -> 26.1.2
    [notice] To update, run: C:\Users\diane\AppData\Local\Programs\Python\Python314\python.exe -m pip install --upgrade pip
    


```python
import folium

# --- 1. Centrer la carte sur l'emprise de l'admin ---
admin_4326 = admin.to_crs(4326)  # Folium/Leaflet travaille en WGS84 (lat/lon)
centroid = admin_4326.geometry.unary_union.centroid
m = folium.Map(
    location=[centroid.y, centroid.x],
    zoom_start=12,
    tiles="CartoDB dark_matter"  # équivalent Leaflet du fond sombre que tu utilises
)

# --- 2. Limite administrative ---
folium.GeoJson(
    admin_4326,
    name="Limite administrative",
    style_function=lambda x: {"color": "white", "weight": 1.5, "fillOpacity": 0}
).add_to(m)

# --- 3. Graphes Waxman (une couche par catégorie, activable/désactivable) ---
for label, edges in wax_graphs.items():
    if edges is None or edges.empty:
        continue
    edges_4326 = edges.to_crs(4326)
    color = layer_colors[label] if isinstance(layer_colors[label], str) else "#{:02x}{:02x}{:02x}".format(
        int(layer_colors[label][0]*255), int(layer_colors[label][1]*255), int(layer_colors[label][2]*255)
    )
    folium.GeoJson(
        edges_4326,
        name=f"Réseau — {label}",
        style_function=lambda x, c=color: {"color": c, "weight": 1, "opacity": 0.4}
    ).add_to(m)

# --- 4. POI (une couche par catégorie, avec popup au clic) ---
for label, pois in poi_layers.items():
    if pois is None or pois.empty:
        continue
    pois_4326 = pois.to_crs(4326)
    color = layer_colors[label] if isinstance(layer_colors[label], str) else "#{:02x}{:02x}{:02x}".format(
        int(layer_colors[label][0]*255), int(layer_colors[label][1]*255), int(layer_colors[label][2]*255)
    )
    fg = folium.FeatureGroup(name=f"POI — {label}")
    for _, row in pois_4326.iterrows():
        folium.CircleMarker(
            location=[row.geometry.y, row.geometry.x],
            radius=3,
            color=color,
            fill=True,
            fill_opacity=0.8,
            popup=label
        ).add_to(fg)
    fg.add_to(m)

# --- 5. Contrôle des couches (case à cocher pour afficher/masquer chaque catégorie) ---
folium.LayerControl(collapsed=False).add_to(m)

# --- 6. Export en fichier HTML autonome ---
m.save("index.html")
```

    C:\Users\diane\AppData\Local\Temp\ipykernel_3292\436636173.py:5: DeprecationWarning: The 'unary_union' attribute is deprecated, use the 'union_all()' method instead.
      centroid = admin_4326.geometry.unary_union.centroid
    


```python
import folium
from folium.plugins import MarkerCluster

# --- 1. Centrer la carte sur l'emprise de l'admin ---
admin_4326 = admin.to_crs(4326)
centroid = admin_4326.geometry.unary_union.centroid

# tiles=None : on n'active aucun fond par défaut, on les ajoute tous manuellement ci-dessous
m = folium.Map(location=[centroid.y, centroid.x], zoom_start=12, tiles=None)

# --- 2. Plusieurs fonds de carte, sélectionnables via le contrôle de couches ---
folium.TileLayer("CartoDB dark_matter", name="Sombre (CartoDB Dark)").add_to(m)
folium.TileLayer("CartoDB positron", name="Clair (CartoDB Positron)").add_to(m)
folium.TileLayer("OpenStreetMap", name="OpenStreetMap").add_to(m)
folium.TileLayer(
    "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
    attr="OpenTopoMap", name="Relief (OpenTopoMap)"
).add_to(m)

# --- 3. Limite administrative ---
folium.GeoJson(
    admin_4326,
    name="Limite administrative",
    style_function=lambda x: {"color": "white", "weight": 1.5, "fillOpacity": 0}
).add_to(m)

# --- 4. Graphes Waxman (réseaux, une couche par catégorie) ---
def to_hex(color):
    if isinstance(color, str):
        return color
    return "#{:02x}{:02x}{:02x}".format(int(color[0]*255), int(color[1]*255), int(color[2]*255))

for label, edges in wax_graphs.items():
    if edges is None or edges.empty:
        continue
    edges_4326 = edges.to_crs(4326)
    color = to_hex(layer_colors[label])
    folium.GeoJson(
        edges_4326,
        name=f"Réseau — {label}",
        style_function=lambda x, c=color: {"color": c, "weight": 1, "opacity": 0.4}
    ).add_to(m)

# --- 5. POI avec clustering (une cluster group par catégorie) ---
for label, pois in poi_layers.items():
    if pois is None or pois.empty:
        continue
    pois_4326 = pois.to_crs(4326)
    color = to_hex(layer_colors[label])

    cluster = MarkerCluster(name=f"POI — {label}")
    for _, row in pois_4326.iterrows():
        folium.CircleMarker(
            location=[row.geometry.y, row.geometry.x],
            radius=4,
            color=color,
            fill=True,
            fill_color=color,
            fill_opacity=0.8,
            popup=label
        ).add_to(cluster)
    cluster.add_to(m)

# --- 6. Contrôle des couches (fonds de carte + catégories, tout activable/désactivable) ---
folium.LayerControl(collapsed=False).add_to(m)

# --- 7. Export ---
m.save("index.html")
```

    C:\Users\diane\AppData\Local\Temp\ipykernel_3292\682809843.py:6: DeprecationWarning: The 'unary_union' attribute is deprecated, use the 'union_all()' method instead.
      centroid = admin_4326.geometry.unary_union.centroid
    


```python
!mkdir "Bordeaux Accessibilite"
```

    Un sous-r‚pertoire ou un fichier Bordeaux Accessibilite existe d‚j….
    


```python
import os
print(os.getcwd())
```

    C:\Users\diane\Desktop\Dossier_jupyterlab
    


```python
import os

# Cherche le dossier Portfolio_Adama sur ton PC
for root, dirs, files in os.walk(r"C:\Users\diane"):
    if "Portfolio_Adama" in dirs:
        print(os.path.join(root, "Portfolio_Adama"))
```

    C:\Users\diane\AppData\Local\GitHubDesktop\app-3.5.4\Portfolio_Adama
    C:\Users\diane\AppData\Local\GitHubDesktop\app-3.5.4\resources\app\Portfolio_Adama
    C:\Users\diane\Documents\GitHub\Portfolio_Adama
    C:\Users\diane\Documents\GitHub\Realisation_Adama\SIG Mobilité\Portfolio_Adama
    C:\Users\diane\Local\GitHubDesktop\app-3.5.4\Portfolio_Adama
    C:\Users\diane\Local\GitHubDesktop\app-3.5.4\resources\app\Portfolio_Adama
    


```python
import os
os.chdir(r"C:\Users\diane\Documents\GitHub\Portfolio_Adama")
print(os.getcwd())  # vérifie que tu es bien au bon endroit
```

    C:\Users\diane\Documents\GitHub\Portfolio_Adama
    


```python
os.makedirs("Bordeaux Accessibilite", exist_ok=True)  # exist_ok évite l'erreur si déjà créé
m.save("Bordeaux Accessibilite/index.html")
```


```python
import os
taille_mo = os.path.getsize("Bordeaux Accessibilite/index.html") / (1024 * 1024)
print(f"{taille_mo:.1f} Mo")
```

    35.6 Mo
    


```python
for label, edges in wax_graphs.items():
    edges_4326 = edges.to_crs(4326)
    edges_4326["geometry"] = edges_4326.geometry.simplify(tolerance=0.0001)  # réduit le nombre de points
    ...
```


```python

```
